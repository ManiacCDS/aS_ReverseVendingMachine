fx_version 'cerulean'
game 'gta5'

author 'aS'
description 'Reverse Vending Machine Prop for FiveM'
version '1.0.0'

data_file 'DLC_ITYP_REQUEST' 'stream/as_rv_machine_prop.ydr.ytyp'